# Caption Deck 🗂️

A small, beginner-friendly web app that generates social media captions and
hashtags. Pick a vibe (travel, food, funny, motivational...), pull a card,
and copy the caption straight to your clipboard.

No build tools, no dependencies, no API keys — just HTML, CSS, and vanilla
JavaScript. Great as a first "real" project to put on GitHub.

## Live demo

Open `index.html` in any browser — that's it. Or deploy it for free with
GitHub Pages (steps below).

## Project structure

```
caption-generator/
├── index.html   # page structure and content
├── style.css    # all visual styling
├── script.js    # caption data + app logic
└── README.md    # this file
```

## How it works

- All the captions and hashtags live in one place: the `CAPTION_DATA` object
  at the top of `script.js`. Each category has a `label`, a list of
  `hashtags`, and a list of `captions`.
- The category chips at the top of the page are built automatically from
  `CAPTION_DATA` — you never have to touch the HTML to add a category.
- Clicking **Pull a card** picks a random caption (never the same one twice
  in a row) and three random hashtags, and shows them on the card.
- Clicking **Copy** uses the browser's Clipboard API to copy the caption and
  hashtags together, ready to paste into Instagram, TikTok, etc.

## Add your own captions

Open `script.js` and find `CAPTION_DATA`. To add a new category:

```js
travel: {
  label: "Travel",
  hashtags: ["#wanderlust", "#roadtrip"],
  captions: [
    "Somewhere new, same old me.",
    "Currently allergic to my own timezone.",
  ],
},
```

Just copy that block, rename the key (e.g. `study`, `gym`, `wedding`), and
fill in your own `label`, `hashtags`, and `captions`. The chip and card UI
pick it up automatically — no other code changes needed.

## Running it locally

You don't need a server for this project — double-click `index.html` and it
opens in your browser. If you prefer a local server (useful for some
browsers' clipboard permissions), you can use:

```bash
# Python 3
python3 -m http.server 8000

# then visit http://localhost:8000
```

## Deploying to GitHub Pages

1. Create a new repository on GitHub and push this folder to it:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Caption Deck"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```
2. On GitHub, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to `Deploy from a branch`,
   pick the `main` branch and `/ (root)` folder, then save.
4. GitHub will give you a live URL (usually
   `https://<your-username>.github.io/<repo-name>/`) within a minute or two.

## Ideas to extend it (good practice exercises)

- Add a "favorites" list using `localStorage` so people can save captions.
- Add a caption **length** filter (short vs. long).
- Add a dark mode toggle.
- Let people submit their own captions through a form and save them.
- Add unit tests for `pickRandomIndex` and `pickHashtags`.

## License

Free to use, modify, and share — MIT License.
