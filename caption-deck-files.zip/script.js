/* =====================================================
   Caption Deck — script.js
   Beginner-friendly walkthrough:
   1. CAPTION_DATA holds all the captions, grouped by category.
   2. We build the category chips from that data automatically.
   3. "Pull a card" picks a random caption + hashtags and shows it.
   4. "Copy" puts the caption + hashtags on the clipboard.
   Add your own captions by editing CAPTION_DATA below — nothing
   else needs to change.
===================================================== */

const CAPTION_DATA = {
  general: {
    label: "General",
    hashtags: ["#goodvibes", "#todayswin", "#justpost", "#momentmade"],
    captions: [
      "Not perfect, just posted.",
      "This is your sign to hit share.",
      "Small moment, main character energy.",
      "Living for the little things.",
      "Filed under: worth remembering.",
    ],
  },
  travel: {
    label: "Travel",
    hashtags: ["#wanderlust", "#passportstamps", "#newplace", "#roadtrip", "#exploremore"],
    captions: [
      "Left my routine at the gate.",
      "Somewhere new, same old me — slightly sunburnt.",
      "Collecting places, not things.",
      "Map says one thing, my feet say another.",
      "Currently allergic to my own timezone.",
    ],
  },
  food: {
    label: "Food",
    hashtags: ["#foodie", "#homecooked", "#eatwell", "#tastetest", "#kitchenwin"],
    captions: [
      "Ate this before it could get cold. No regrets.",
      "Recipe: follow instructions, then improvise wildly.",
      "10/10, would eat again immediately.",
      "Cooking is just chemistry you get to eat.",
      "This plate is doing a lot of emotional labor today.",
    ],
  },
  selfie: {
    label: "Selfie",
    hashtags: ["#justme", "#nofilter", "#selfcare", "#feelinggood", "#ootd"],
    captions: [
      "New angle, same chaos.",
      "Confidence: rented, not owned. Wearing it anyway.",
      "Proof I left the house today.",
      "Lighting was good so I had to.",
      "One (1) picture that doesn't look weird. Posting immediately.",
    ],
  },
  motivational: {
    label: "Motivational",
    hashtags: ["#keepgoing", "#growth", "#mindset", "#showup", "#progress"],
    captions: [
      "Small steps still count as moving.",
      "Doing it scared beats not doing it at all.",
      "Progress, not perfection — framed and hung on the wall.",
      "The version of you a year ago would be proud.",
      "Bet on yourself. The odds are better than you think.",
    ],
  },
  funny: {
    label: "Funny",
    hashtags: ["#lol", "#relatable", "#send", "#itwasajoke", "#chaosgoodmorning"],
    captions: [
      "Personality: 90% snacks, 10% overthinking.",
      "I peaked at this exact moment.",
      "Running on caffeine and spite today.",
      "This post has no plot, just vibes.",
      "Emotionally I am a golden retriever that saw a squirrel.",
    ],
  },
  pets: {
    label: "Pets",
    hashtags: ["#petsofinstagram", "#goodboy", "#catsofinstagram", "#dogmom", "#furbaby"],
    captions: [
      "My tiny roommate pays rent in chaos and love.",
      "Officially owned by this creature now.",
      "Zero productivity, infinite cuteness.",
      "Best decision I never regret making.",
      "This one's the real main character of the house.",
    ],
  },
  fitness: {
    label: "Fitness",
    hashtags: ["#fitnessjourney", "#trainhard", "#nodaysoff", "#strongnotskinny", "#pr"],
    captions: [
      "Showed up when the couch made a better offer.",
      "New personal record, old amount of soreness.",
      "One more rep than yesterday. That's the whole plan.",
      "Sweat now, brag later.",
      "Consistency over intensity, every single time.",
    ],
  },
};

// Keep track of state so we don't repeat the same caption twice in a row
let currentCategory = "general";
let lastCaptionIndex = -1;

// --- Grab elements once ---
const categoryRow = document.getElementById("categoryRow");
const card = document.getElementById("card");
const cardTab = document.getElementById("cardTab");
const captionText = document.getElementById("captionText");
const hashtagRow = document.getElementById("hashtagRow");
const cardIndex = document.getElementById("cardIndex");
const pullBtn = document.getElementById("pullBtn");
const copyBtn = document.getElementById("copyBtn");
const copyLabel = document.getElementById("copyLabel");
const toast = document.getElementById("toast");

// --- Build the category chips from CAPTION_DATA ---
function renderChips() {
  Object.keys(CAPTION_DATA).forEach((key) => {
    const chip = document.createElement("button");
    chip.type = "button";
    chip.className = "chip" + (key === currentCategory ? " active" : "");
    chip.textContent = CAPTION_DATA[key].label;
    chip.dataset.category = key;

    chip.addEventListener("click", () => {
      currentCategory = key;
      lastCaptionIndex = -1;
      updateActiveChip();
      pullCard();
    });

    categoryRow.appendChild(chip);
  });
}

function updateActiveChip() {
  document.querySelectorAll(".chip").forEach((chip) => {
    chip.classList.toggle("active", chip.dataset.category === currentCategory);
  });
}

// --- Pick a random caption from the current category ---
function pickRandomIndex(length) {
  if (length === 1) return 0;
  let index;
  do {
    index = Math.floor(Math.random() * length);
  } while (index === lastCaptionIndex);
  return index;
}

// --- Pick 3 random hashtags from the current category ---
function pickHashtags(pool) {
  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(3, shuffled.length));
}

// --- Fill in and show a new card ---
function pullCard() {
  const data = CAPTION_DATA[currentCategory];
  const index = pickRandomIndex(data.captions.length);
  lastCaptionIndex = index;

  cardTab.textContent = data.label.toLowerCase();
  captionText.textContent = data.captions[index];

  hashtagRow.innerHTML = "";
  pickHashtags(data.hashtags).forEach((tag) => {
    const span = document.createElement("span");
    span.className = "hashtag";
    span.textContent = tag;
    hashtagRow.appendChild(span);
  });

  cardIndex.textContent = `card ${index + 1} of ${data.captions.length}`;

  // Little flip animation each time a new card is pulled
  card.classList.remove("flip");
  void card.offsetWidth; // restart the animation
  card.classList.add("flip");

  hideToast();
}

// --- Copy caption + hashtags to clipboard ---
async function copyCard() {
  const hashtags = Array.from(hashtagRow.children)
    .map((el) => el.textContent)
    .join(" ");
  const fullText = `${captionText.textContent}\n\n${hashtags}`;

  try {
    await navigator.clipboard.writeText(fullText);
    showToast("Copied to clipboard ✓");
  } catch (err) {
    showToast("Couldn't copy — select the text manually.");
  }
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(hideToast, 2200);
}

function hideToast() {
  toast.classList.remove("show");
}

// --- Wire up buttons ---
pullBtn.addEventListener("click", pullCard);
copyBtn.addEventListener("click", copyCard);

// --- Init ---
renderChips();
